// MissedGoal.js
import React from 'react';

const MissedGoal = () => {
  return <div><p>Goal missed!</p></div>;
};

export default MissedGoal;
