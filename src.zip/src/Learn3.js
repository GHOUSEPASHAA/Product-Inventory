import React from 'react'

export default function Learn3(props) {
  return (
    <div>
      {props.title}
    </div>
  )
}
