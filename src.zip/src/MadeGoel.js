import React from 'react'

const MadeGoel = () => {
  return <div><p>Goal scored!</p></div>;
}

export default MadeGoel
