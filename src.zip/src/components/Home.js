import React from 'react'
import Learn3 from '../Learn3'

export default function Home() {
  return (
    <div>
      home
      <Learn3 title="jacky"/>
    </div>
  )
}
